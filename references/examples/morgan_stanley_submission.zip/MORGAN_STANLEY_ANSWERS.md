# Morgan Stanley Accelerator (MSISV) - Complete Application Answers

**Company:** Boostability
**Founder:** Efrat Segal-Mesika
**Generated:** 2026-03-12

---

## 1. Revenue Projection for Full-Year 2026

We're projecting $108,000-$120,000 in revenue for 2026, based on scaling to approximately 1,000 students across multiple institutional partners. Here's how that breaks down: Our pricing is $12 per student per month. The academic year runs roughly 9 months (September-May), so 1,000 students x $12/month x 9 months equals $108,000. The slight variance accounts for some schools potentially onboarding mid-year and revenue flowing across the calendar year as partnerships launch at different times.

We're currently running a paid pilot with an institutional partner. Our 2026 goal is to expand to at least 3-4 schools beyond our current pilot, each serving 200-300 students, to reach that 1,000-student target. This is realistic based on what we're learning from the pilot - schools that see strong outcomes renew quickly and expand adoption. We're not projecting aggressive revenue growth beyond 2026, but this base gives us runway to prove the business model works and to invest in retention and institutional relationships that will drive much larger 2027 revenue.

It's worth noting that our revenue is directly tied to impact. If students aren't showing measurable improvement in on-time submissions and engagement, schools don't renew and we don't hit these numbers. That's actually our safeguard - we can't grow revenue by compromising on student outcomes.

---

## 2. Current Monthly Net Cash Burn

Our current monthly net cash burn is approximately $2,500-$3,000. Here's how we get there:

Base operational costs run about $400 per month (Bubble platform license, GPT tokens, SMS infrastructure, 24/7 support, and ongoing staff coordination). On top of that, we're actively onboarding our second institutional partner right now. Our onboarding costs per school average $7,700 spread over 4 months, which comes to about $1,925 per month during the onboarding period. That puts us at approximately $2,325 per month while actively onboarding, plus I'm covering founder costs from personal runway.

The key thing is our burn is directly tied to growth. When we're not onboarding new schools, our base burn drops to $400/month. When we're scaling to new partners, we deliberately spend the $7,700 per school knowing that creates customer acquisition that pays for itself through Year 2 renewals with high margins.

We started with personal runway to get the pilot working and prove outcomes. Now that we have a paid pilot generating revenue, each new school we onboard is partially offset by the revenue they generate. By 2027, as more schools reach Year 2 renewal (where margins are 92%+), our overall burn dramatically improves or flips to profitability depending on growth rate.

We're not burning capital recklessly. Every dollar we spend on onboarding is an investment in a customer relationship that generates recurring revenue. That's how we eventually achieve the unit economics we modeled.

---

## 3. Problem Statement

Universities lose between 25K and 40K every time a student walks away due to procrastination, time management, and accountability. The students most likely to walk away are already underserved: first generation, minorities, returning adults, and those with unmet learning needs. Traditional support requires jumping through hoops most of them cannot clear. Nobody is solving for these students at scale.

---

## 4. Product or Solution

Boostability helps the students who struggle most, first generation, minorities, disabled, neurodivergent, and returning adults, overcome procrastination, time management, and accountability challenges. Our mobile app, powered by AI, breaks overwhelming assignments into daily micro-tasks, delivers personalized plans, and sends SMS nudges that stick. Students rebuild confidence through daily wins instead of drowning in overwhelm.

For faculty and academic leaders, Boostability 360 flips the script: real-time disengagement alerts and early intervention dashboards replace crisis response with proactive support. Faculty step in before withdrawal happens. Students get support they could never access before. Universities stop losing students.

---

## 5. Technology Stack

**Current Stack:**
- Platform: Bubble.io (no-code, rapid iteration)
- AI Models: ChatGPT 4.0 for task breakdown, personalization, and smart alerts
- Mobile: Bubble.io responsive design
- SMS Infrastructure: Twilio/similar for accountability nudges
- Database: Built into Bubble.io

**Planned (2026-2027):**
- Direct LMS integrations: Canvas and CourseKey (for seamless single-sign-on and native faculty workflows)
- Enhanced mobile app: Native apps if scale demands it
- Advanced analytics: Data warehouse for institutional reporting

**Why Bubble.io:** Lets us move fast at early stage, iterate based on user feedback, and scale without hiring a massive engineering team. As we grow and have product-market fit, we can migrate to custom infrastructure if needed.

---

## 6. Scaling Challenges

Scaling Boostability means earning the right to be used, and capital alone cannot do that. Institutional trust in AI is our first wall: universities protecting vulnerable students move cautiously, so we lead with privacy-first architecture and pilot evidence that speaks louder than promises.

Our second challenge is habit formation: our real competition is not other apps, it is inertia. Every feature we build fights it through micro-wins and perfectly timed nudges.

Our third is faculty adoption: Boostability 360 only saves students if faculty act on what they see, so we embed alerts into tools they already use, making intervention the path of least resistance.

We are not waiting for trust to appear. We are engineering it.

---

## 7. Revenue Model

Schools pay us $12/student/month. That is it. We do not monetize student data. We do not sell to third parties. Schools are our only revenue source, and we think that is the right way to build this.

The fee breaks into two parts. $10/student/month powers the student app: personalized task breakdown, study plans, and SMS nudges that build accountability over time. $2/student/month powers Boostability 360, which covers everything the institution needs to make it work: student and faculty onboarding, faculty training, customized impact reports, and the integration layer that connects Boostability into the school's existing workflows (including LMS integration for schools that want it) so adoption actually happens.

Schools start with a pilot cohort of 100 students. Year 1 revenue: 100 students x $12 x 9 months = $10,800. With $7,700 onboarding costs, first year margin is ~28%. Year 2, the same school expands to 300 students with zero new acquisition cost: 300 x $12 x 9 months = $32,400. Margin jumps to 92%+. One renewal funds the next school's acquisition.

As the relationship deepens, schools can unlock advanced analytics and deeper LMS integrations, adding $3,000 to $8,000 in additional annual value.

We grow when schools renew. Schools renew when students succeed. That is not a coincidence. That is impact.

---

## 8. Traction

The best proof we have is what students said after six months with Boostability.

From January to June 2025, 100 students across 5 leading US universities completed our structured pilot. Student surveys and direct quotes confirmed the same thing: tasks that felt impossible became manageable, and showing up daily started to feel worth it.

That outcome data opened the door to our first paid institutional contract, a signed paid pilot with a chain of schools serving 14,000 students, covering 100 students in the first cohort. An institution that size does not sign without confidence in results.

Our institutional credibility runs deep. We are a startup in residence at Pace University, a Columbia University eLab Fellow, and supported by Google for Startups and Microsoft Founders Hub. These are not badges. They are relationships that open doors and validate our approach with the people who matter in higher ed.

---

## 9. Customers & Go-To-Market Strategy

Our go-to-market is deliberately focused. Direct outreach, warm introductions, and higher education conference presence put us in front of the right decision makers at the right moment. Our traction does the selling: a completed 100+ student pilot across 5 universities, and a signed paid contract of 100 students with a chain of 14,000 students.

Pilot schools that see results refer peers. That is our highest trust and lowest cost acquisition channel, and the engine we are building.

---

## 10. Competitors & Competitive Advantage

The real competition is not another app. It is the status quo. Universities patch student support together with three inadequate tools: advisors and disability staff who are stretched beyond capacity, LMS platforms repurposed for engagement they were never designed to drive, and consumer productivity apps students abandon within weeks.

Boostability is the first solution built specifically for institutional scale. One platform replaces the patchwork: proactive AI support that reaches every struggling student, not just the ones who self-advocate. That is the gap no existing substitute fills, and the reason universities sign.

---

## 11. Pivots

Boostability has pivoted twice, and both times the market told us what to do.

After our 100 student pilot in 2025, data showed that academic struggle does not require a diagnosis. First generation, non-traditional, and returning adult learners were hitting the same walls. Staying ADHD-only meant ignoring the majority of students universities were losing. We broadened our focus. Outcome: a larger market and stronger alignment with institutional equity goals.

When we began conversations with universities, they asked a question our student app could not answer: how do we know which students need help before they disappear? We built Boostability 360 to answer that question directly. Outcome: our first signed paid institutional contract with a chain of 14,000 students and a replicable model for every school we enter.

---

## 12. Founders & Management Team

Efrat Segal founded Boostability because she could not find it anywhere else.

She trained in Mamram and Unit 8200, holds a BA in Computer Science from Reichman University and an MBA from Babson College, and spent years leading product at JFrog, Redis, and Bizzabo, scaling enterprise platforms across complex institutional environments. She brings the technical depth and product instincts to build this, and the business training to scale it.

What makes Efrat's founder market fit unmatched is what she carries alongside those credentials. She navigates ADHD herself every day and is raising children with ADHD and learning disabilities. She knows this problem from the inside, not as a researcher or observer, but as someone who has lived it and refused to accept that nothing better existed for the students who need it most.

That combination has earned Boostability a paid institutional contract, a Pace University residency, and a Columbia eLab fellowship.

Our advisor Tamir Harush, Director of The Front Yard Program at Pace University, brings deep expertise in education innovation and institutional partnerships. We are actively building our clinical and technical team.

---

## 13. Program Priorities

Boostability enters MSISV with a paid institutional contract and a proven product. What we need now is the infrastructure to scale what is working.

Our three priorities are:

**First,** leveraging Morgan Stanley's investor ecosystem access and banking relationships to build the right pre-seed syndicate and lay the foundation for our 2026 Series A.

**Second,** working with MSISV mentors and entrepreneurs in residence to sharpen our fundraising narrative, organizational structure, and governance so Boostability is built to scale from day one.

**Third,** developing a rigorous impact measurement framework with guidance from Morgan Stanley's sustainability experts that proves student outcomes at every renewal and positions Boostability as the institutional standard for equitable academic support.

We are not here to validate the idea. We are here to build the machine that delivers equitable academic support to every student who needs it.

---

## 14. Closing Statement

Three forces are converging right now that Boostability is uniquely positioned to capture. University retention budgets are being cut while 1 in 3 college students struggles to complete what they start. Student support demand is outpacing every human solution institutions can afford. And AI has reached the point where genuinely personalized, proactive academic support can be delivered at institutional scale for the first time.

The opportunity spans 19 million college students across 6,000 US institutions. Our immediate target of 1,200 institutions with 2,000 or more students represents a $14.4 million licensing market, with a path to $72 million as we expand across the full institutional landscape.

The market is here. The problem is acute. The timing is now. The question is not whether this gets solved. It is who builds the standard.

---

**Notes:**
Morgan Stanley Accelerator (MSISV) application answers generated 2026-03-12. All answers reflect Boostability's current stage, traction, and strategic positioning. Answers emphasize founder-market fit, proven product-market validation through paid institutional contract, and clear path to Series A funding.
